import java.util.*;

public class ReportGenerator {

    // Attributes
    private String reportType;
    private Object data;

    // Constructor to initialize reportType and data
    public ReportGenerator(String reportType, Object data) {
        this.reportType = reportType;
        this.data = data;
    }

    // Generate the report based on the reportType
    public String generateReport() {
        switch (reportType) {
            case "PATIENT":
                return generatePatientReport((Patient) data);
            case "APPOINTMENT":
                return generateAppointmentReport((List<Appointment>) data);
            case "REVENUE":
                return generateRevenueReport((List<Billing>) data);  // Example: Revenue based on appointments
            default:
                return "Invalid report type";
        }
    }

    // Generate report for a patient
    public String generatePatientReport(Patient patient) {
        String report = "Patient Report\n===============\n";
        report =report+patient.getPatientInfo() + "\n";


        report =report+ "Medical History:\n";
        List<String> medicalHistory = patient.getMedicalHistory();
        for (int i = 0; i < medicalHistory.size(); i++) {
            report =report+ "- " + medicalHistory.get(i) + "\n";
        }

        // Visit Records
        report += "Visit Records:\n";
        List<String> visitRecords = patient.getVisitRecords();
        for (int i = 0; i < visitRecords.size(); i++) {
            report =report+ visitRecords.get(i) + "\n";
        }

        return report;
    }


    // Generate report for appointments
    public String generateAppointmentReport(List<Appointment> appointments) {
        String report = "Appointment Report\n";
        report =report+ "=================\n";

        // Sort appointments by date using Quick Sort
        List<Appointment> sortedAppointments = new ArrayList<>(appointments);
        sortAppointments(sortedAppointments);

        for (int i = 0; i < sortedAppointments.size(); i++) {
            Appointment appo = sortedAppointments.get(i);
            report =report+ String.format("ID: %d, Patient: %s, Date: %s, Time: %s, Status: %s\n",
                    appo.getAppointmentID(), appo.getPatient().getName(), appo.getDate(), appo.getTime(), appo.getStatus());
        }

        return report;
    }

    public String generateRevenueReport(List<Billing> billingRecords) {
        StringBuilder report = new StringBuilder("Revenue Report\n===============\n");

        double totalRevenue = 0;
        for (Billing billing : billingRecords) {
            double payments = billing.getTotalPayments();
            totalRevenue += payments;
            report.append(String.format("Patient: %s, Payments Made: $%.2f\n",
                    billing.getPatient().getName(), payments));
        }

        report.append(String.format("\nTotal Revenue: $%.2f", totalRevenue));
        return report.toString();
    }


    // Merge Sort for Visit Records (Sorting visit history)
    private void sortVisitRecords(List<String> records) {
        if (records.size() <= 1) return;

        int mid = records.size() / 2;
        List<String> left = new ArrayList<>(records.subList(0, mid));
        List<String> right = new ArrayList<>(records.subList(mid, records.size()));

        sortVisitRecords(left);
        sortVisitRecords(right);
        mergeVisitRecords(records, left, right);
    }

    private void mergeVisitRecords(List<String> result, List<String> left, List<String> right) {
        int i = 0, j = 0, k = 0;

        while (i < left.size() && j < right.size()) {
            if (left.get(i).compareTo(right.get(j)) < 0) {
                result.set(k++, left.get(i++));
            } else {
                result.set(k++, right.get(j++));
            }
        }

        while (i < left.size()) result.set(k++, left.get(i++));
        while (j < right.size()) result.set(k++, right.get(j++));
    }

    // Quick Sort for Appointments (Sorting by appointment date)
    private void sortAppointments(List<Appointment> appointments) {
        appointments.sort((a1, a2) -> a1.getDate().compareTo(a2.getDate()));
    }
}

