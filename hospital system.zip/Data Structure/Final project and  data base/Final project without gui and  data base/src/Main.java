import java.sql.Date;
import java.util.*;
import java.sql.*;

public class Main {
    private static Connection connectToDatabase() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/patientmanagementsystem"; // Replace with your DB details
        String username = "root"; // Replace with your DB username
        String password = "Maro1234"; // Replace with your DB password
        return DriverManager.getConnection(url, username, password);
    }
//    // Helper method to convert time to 24-hour format
//    private static boolean isValidDate(String date) {
//        try {
//            java.sql.Date.valueOf(date);
//            return true;
//        } catch (IllegalArgumentException e) {
//            return false;
//        }
//    }
//    private static boolean isValidTime(String time) {
//        try {
//            java.text.SimpleDateFormat inputFormat = new java.text.SimpleDateFormat("hh:mm a");
//            inputFormat.setLenient(false);
//            inputFormat.parse(time);
//            return true;
//        } catch (java.text.ParseException e) {
//            return false;
//        }
//    }

    private static String convertTo24HourFormat(String time) {
        java.text.SimpleDateFormat inputFormat = new java.text.SimpleDateFormat("hh:mm a");
        java.text.SimpleDateFormat outputFormat = new java.text.SimpleDateFormat("HH:mm");
        try {
            return outputFormat.format(inputFormat.parse(time));
        } catch (java.text.ParseException e) {
            throw new IllegalArgumentException("Invalid time format.");
        }
    }
    public static void main(String[] args) {
        // Initialize the Patient Management System
        PatientManagementSystem pms = new PatientManagementSystem();
        Scanner scanner = new Scanner(System.in);
        WaitingList waitingList= new WaitingList();


        while (true) {
            // Display the menu options
            System.out.println("\n--- Hosiptal Management System ---");
            System.out.println("1. Add Patient");
            System.out.println("2. Schedule Appointment");
            System.out.println("3. Display Patients");
            System.out.println("4. Display Waiting List");
            System.out.println("5. Update Contact Information");
            System.out.println("6. Exit");


            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
//                    System.out.print("Enter patient name: ");
//                    String name = scanner.nextLine();
//                    System.out.print("Enter patient age: ");
//                    int age = scanner.nextInt();
//                    scanner.nextLine(); // Consume newline character
//                    System.out.print("Enter patient email: ");
//                    String email = scanner.nextLine();
//                    System.out.print("Enter priority (higher number means higher priority): ");
//                    int priority = scanner.nextInt();
//                    scanner.nextLine(); // Consume newline character
//
//                    // Input medical history
//                    List<String> medicalHistory = new ArrayList<>();
//                    System.out.println("Enter medical history (type 'done' to finish):");
//                    while (true) {
//                        System.out.print("Medical History Entry: ");
//                        String historyEntry = scanner.nextLine();
//                        if (historyEntry.equalsIgnoreCase("done")) {
//                            break;
//                        }
//                        medicalHistory.add(historyEntry);
//                    }
//
//                    // Create patient and add to system
//                    int patientID = (pms.patientBST.getSize() + 1);  // Simple patient ID
////                    Patient patient = new Patient(patientID, name, age, email, priority);
//                    for (String entry : medicalHistory) {
//                        patient.getMedicalHistory().add(entry); // Add history to patient
//                    }
//                    pms.addPatient(patient);
//                    System.out.println("Patient added successfully. Your ID is " + patientID);
//                    waitingList.addToWaitList(patient);
//                    break;


                    ///for the data baseee bounussss

                    System.out.print("Enter patient name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter patient age: ");
                    int age = scanner.nextInt();
                    scanner.nextLine(); // Consume newline character
                    System.out.print("Enter patient email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter priority (higher number means higher priority): ");
                    int priority = scanner.nextInt();
                    scanner.nextLine(); // Consume newline character

                    // Input medical history
                    StringBuilder medicalHistoryBuilder = new StringBuilder();
                    System.out.println("Enter medical history (type 'done' to finish):");
                    while (true) {
                        System.out.print("Medical History Entry: ");
                        String historyEntry = scanner.nextLine();
                        if (historyEntry.equalsIgnoreCase("done")) {
                            break;
                        }
                        medicalHistoryBuilder.append(historyEntry).append("; "); // Separate entries with a semicolon
                    }

                    String medicalHistory = medicalHistoryBuilder.toString().trim(); // Final medical history string

                    // Insert data into the database
                    try (Connection connection = connectToDatabase()) {
                        String insertPatientSQL = "INSERT INTO patients (name, age, ContactInfo, priority, medical_history) VALUES (?, ?, ?, ?, ?)";
                        try (PreparedStatement statement = connection.prepareStatement(insertPatientSQL)) {
                            statement.setString(1, name);
                            statement.setInt(2, age);
                            statement.setString(3, email);
                            statement.setInt(4, priority);
                            statement.setString(5, medicalHistory);

                            int rowsInserted = statement.executeUpdate();
                            if (rowsInserted > 0) {
                                System.out.println("Patient added successfully!");
                            }
                        }
                    } catch (SQLException e) {
                        System.out.println("Error adding patient to database: " + e.getMessage());
                    }
                    break;

//


                case 2:

//// Schedule an appointment
//                    System.out.print("Enter patient ID to schedule appointment: ");
//                    int patientIDToSchedule = scanner.nextInt();
//                    scanner.nextLine(); // Consume newline character
//                    System.out.print("Enter appointment date (YYYY-MM-DD): ");
//                    String date = scanner.nextLine();
//                    System.out.print("Enter appointment time (HH:MM, 24-hour format): ");
//                    String time = scanner.nextLine();
//
//                    try (Connection connection = connectToDatabase()) {
//                        // Check if the patient exists in the database
//                        String findPatientSQL = "SELECT * FROM patients WHERE patientID = ?";
//                        try (PreparedStatement findPatientStatement = connection.prepareStatement(findPatientSQL)) {
//                            findPatientStatement.setInt(1, patientIDToSchedule);
//                            ResultSet patientResult = findPatientStatement.executeQuery();
//
//                            if (patientResult.next()) {
//                                // Patient exists, proceed to schedule the appointment
//                                String insertAppointmentSQL = "INSERT INTO appointments (patientID, appointment_date, appointment_time, status) VALUES (?, ?, ?, ?)";
//                                try (PreparedStatement appointmentStatement = connection.prepareStatement(insertAppointmentSQL)) {
//                                    appointmentStatement.setInt(1, patientIDToSchedule);
//                                    appointmentStatement.setDate(2, Date.valueOf(date)); // Convert String to SQL Date
//                                    appointmentStatement.setTime(3, Time.valueOf(time)); // Convert String to SQL Time
//                                    appointmentStatement.setString(4, "Scheduled"); // Default status
//                                    appointmentStatement.executeUpdate();
//
//                                    System.out.println("Appointment scheduled successfully for patient ID " + patientIDToSchedule +
//                                            " on " + date + " at " + time + " with status 'Scheduled'.");
//
//                                    // Optionally, add the visit record in memory
//                                    String visitRecord = "Appointment scheduled for " + date + " at " + time;
//                                    Patient patientToSchedule = pms.findPatient(patientIDToSchedule);
//                                    if (patientToSchedule != null) {
//                                        patientToSchedule.addVisitRecord(visitRecord);
//                                    }
//                                }
//                            } else {
//                                System.out.println("Patient not found.");
//                            }
//                        }
//                    } catch (SQLException e) {
//                        System.out.println("Error scheduling appointment: " + e.getMessage());
//                    }
//                    break;
// Schedule an appointment



//                    // Schedule an appointment
//                    System.out.print("Enter patient ID to schedule appointment: ");
//                    int patientIDToSchedule = scanner.nextInt();
//                    scanner.nextLine(); // Consume newline character
//                    System.out.print("Enter appointment date (YYYY-MM-DD): ");
//                    String date = scanner.nextLine();
//                    System.out.print("Enter appointment time (HH:MM AM/PM): ");
//                    String time = scanner.nextLine();
//
//                    // Validate if patient exists
//                    String checkPatientQuery = "SELECT PatientID FROM Patients WHERE PatientID = ?";
//                    String insertAppointmentQuery = "INSERT INTO Appointments (PatientID, Date, Time) VALUES (?, ?, ?)";
//
//                    try (Connection connection = connectToDatabase()) {
//                        // Check if the patient exists
//                        try (PreparedStatement checkStatement = connection.prepareStatement(checkPatientQuery)) {
//                            checkStatement.setInt(1, patientIDToSchedule);
//                            try (ResultSet resultSet = checkStatement.executeQuery()) {
//                                if (!resultSet.next()) {
//                                    System.out.println("Patient not found.");
//                                    break;
//                                }
//                            }
//                        }
//
//                        // Insert the appointment into the database
//                        try (PreparedStatement insertStatement = connection.prepareStatement(insertAppointmentQuery)) {
//                            insertStatement.setInt(1, patientIDToSchedule);
//                            insertStatement.setDate(2, java.sql.Date.valueOf(date)); // Convert to SQL Date
//                            insertStatement.setTime(3, java.sql.Time.valueOf(convertTo24HourFormat(time))); // Convert to SQL Time
//
//                            int rowsInserted = insertStatement.executeUpdate();
//                            if (rowsInserted > 0) {
//                                System.out.println("Appointment successfully scheduled.");
//                            } else {
//                                System.out.println("Failed to schedule appointment.");
//                            }
//                        }
//                    } catch (SQLException e) {
//                        System.out.println("Database error: " + e.getMessage());
//                    } catch (IllegalArgumentException e) {
//                        System.out.println("Input error: " + e.getMessage());
//                    }
//                    break;
//
                    // Schedule an appointment
                    System.out.print("Enter patient ID to schedule appointment: ");
                    int patientIDToSchedule = scanner.nextInt();
                    scanner.nextLine(); // Consume newline character

                    System.out.print("Enter appointment date (as a string, e.g., '25-Dec-2024'): ");
                    String date = scanner.nextLine();

                    System.out.print("Enter appointment time (as a string, e.g., '10:30 AM'): ");
                    String time = scanner.nextLine();

                    String checkPatientQuery = "SELECT PatientID FROM Patients WHERE PatientID = ?";
                    String insertAppointmentQuery = "INSERT INTO Appointments (PatientID, Date, Time) VALUES (?, ?, ?)";

                    try (Connection connection = connectToDatabase()) {
                        // Check if the patient exists
                        try (PreparedStatement checkStatement = connection.prepareStatement(checkPatientQuery)) {
                            checkStatement.setInt(1, patientIDToSchedule);
                            try (ResultSet resultSet = checkStatement.executeQuery()) {
                                if (!resultSet.next()) {
                                    System.out.println("Patient not found.");
                                    break;
                                }
                            }
                        }

                        // Insert the appointment into the database
                        try (PreparedStatement insertStatement = connection.prepareStatement(insertAppointmentQuery)) {
                            insertStatement.setInt(1, patientIDToSchedule);
                            insertStatement.setString(2, date); // Use date as a string
                            insertStatement.setString(3, time); // Use time as a string

                            int rowsInserted = insertStatement.executeUpdate();
                            if (rowsInserted > 0) {
                                System.out.println("Appointment successfully scheduled.");
                            } else {
                                System.out.println("Failed to schedule appointment.");
                            }
                        }
                    } catch (SQLException e) {
                        System.out.println("Database error: " + e.getMessage());
                    }
                    break;
//
//
// Schedule an appointment
//                    System.out.print("Enter patient ID to schedule appointment: ");
//                    int patientIDToSchedule = scanner.nextInt();
//                    scanner.nextLine(); // Consume newline character
//                    System.out.print("Enter appointment date (YYYY-MM-DD): ");
//                    String date = scanner.nextLine();
//                    System.out.print("Enter appointment time (HH:MM AM/PM): ");
//                    String time = scanner.nextLine();
//
//                    // Find the patient
//                    Patient patientToSchedule = pms.findPatient(patientIDToSchedule);
//                    if (patientToSchedule != null) {
//                        // Schedule the appointment
//                        Appointment appointment = new Appointment(pms.appointmentRecords.size() + 1, patientToSchedule, date, time);
//                        pms.scheduleAppointment(patientIDToSchedule, date, time);
//
//                        // Add the visit record for this patient
//                        String visitRecord = "Appointment scheduled for " + date + " at " + time;
//                        patientToSchedule.addVisitRecord(visitRecord);  // Add the visit record
//
//                    } else {
//                        System.out.println("Patient not found.");
//                    }
//                    break;
//
//
                case 14:
                    // Cancel an appointment
                    System.out.print("Enter patient ID to cancel appointment: ");
                    int patientIDToCancel = scanner.nextInt();
                    pms.cancelAppointment(patientIDToCancel);
                    waitingList.removeFromWaitList(patientIDToCancel); // Removes the specific patient
                    break;


                case 9:
                    // Add payment for a patient
                    System.out.print("Enter patient ID to make payment: ");
                    int patientIDToPay = scanner.nextInt();
                    System.out.print("Enter payment amount: ");
                    double paymentAmount = scanner.nextDouble();

                    Patient patientPay = pms.findPatient(patientIDToPay);
                    if (patientPay != null) {
                        Billing billing = pms.findBillingRecord(patientPay);
                        billing.addPayment(paymentAmount);

                        // Display updated payment status and remaining balance
                        System.out.println("Payment added successfully!");
                        System.out.println("Outstanding Balance: $" + billing.getOutstandingBalance());
                    } else {
                        System.out.println("Patient not found.");
                    }
                    break;

                case 12:
                    // Generate and display report
                    System.out.print("Enter report type (PATIENT, APPOINTMENT, REVENUE): ");
                    String reportType = scanner.nextLine();
                    if (reportType.equalsIgnoreCase("PATIENT")) {
                        System.out.print("Enter patient ID for report: ");
                        int reportPatientID = scanner.nextInt();
                        scanner.nextLine(); // Consume newline character
                        Patient reportPatient = pms.findPatient(reportPatientID);
                        if (reportPatient != null) {
                            String patientReport = pms.generateReport("PATIENT", reportPatient);
                            System.out.println(patientReport);
                        }
                    } else if (reportType.equalsIgnoreCase("APPOINTMENT")) {
                        String appointmentReport = pms.generateReport("APPOINTMENT", pms.appointmentRecords);
                        System.out.println(appointmentReport);}
                    else if (reportType.equalsIgnoreCase("REVENUE")) {
                        String revenueReport = pms.generateReport("REVENUE", pms.billingRecords); // Pass billing records
                        System.out.println(revenueReport);
                    } else {
                        System.out.println("Invalid report type.");
                    }
                    break;

                case 3:
                    // Display all patients

                    ///for the data baseee bounussss

                    System.out.println("\n--- Patient List ---");
                    try (Connection connection = connectToDatabase()) {
                        String query = "SELECT * FROM patients";
                        try (Statement statement = connection.createStatement()) {
                            ResultSet resultSet = statement.executeQuery(query);

                            while (resultSet.next()) {
                                int patientID = resultSet.getInt("patientID");
                                String nameget = resultSet.getString("name");
                                int ageget = resultSet.getInt("age");
                                String emailget = resultSet.getString("ContactInfo");
                                int priorityget = resultSet.getInt("priority");
                                String medicalHistoryget = resultSet.getString("medical_history");

                                System.out.println("Patient ID: " + patientID);
                                System.out.println("Name: " + nameget);
                                System.out.println("Age: " + ageget);
                                System.out.println("Email: " + emailget);
                                System.out.println("Priority: " + priorityget);
                                System.out.println("Medical History: " + medicalHistoryget);
                                System.out.println("----------------------------");
                            }
                        }
                    } catch (SQLException e) {
                        System.out.println("Error retrieving patient data: " + e.getMessage());
                    }
                    break;
                // pms.displayPatients();
//                    pms.displayPatients();  // Use BST's in-order traversal for display

                case 7:
                    // Display all appointments
                    pms.displayAppointments();
                    break;

                case 8:
//
//                     Display billing records
                    pms.displayBillingRecords();
                    break;

                case 4:
//                    // Display waiting list
//                    waitingList.displayWaitList();
                    //break;


                    // for data base bounus only
                // Display all patients ordered by priority
                    System.out.println("\n--- Patient List (Ordered by Priority) ---");
                    try (Connection connection = connectToDatabase()) {
                        String query = "SELECT * FROM patients ORDER BY priority DESC";
                        try (Statement statement = connection.createStatement()) {
                            ResultSet resultSet = statement.executeQuery(query);

                            while (resultSet.next()) {
                                int patientID = resultSet.getInt("patientID");
                                String name8 = resultSet.getString("name");
                                int age8 = resultSet.getInt("age");
                                String email8 = resultSet.getString("Contactinfo");
                                int priority8 = resultSet.getInt("priority");
                                String medicalHistory8 = resultSet.getString("medical_history");

                                System.out.println("Patient ID: " + patientID);
                                System.out.println("Name: " + name8);
                                System.out.println("Age: " + age8);
                                System.out.println("Email: " + email8);
                                System.out.println("Priority: " + priority8);
                                System.out.println("Medical History: " + medicalHistory8);
                                System.out.println("----------------------------");
                            }
                        }
                    } catch (SQLException e) {
                        System.out.println("Error retrieving patient data: " + e.getMessage());
                    }
                    break;

                case 10:
                    // Generate bill for a patient
                    System.out.print("Enter patient ID to generate bill: ");
                    int patientIDToBill = scanner.nextInt();
                    scanner.nextLine(); // Consume newline character

                    // Find the patient
                    Patient patientToBill = pms.findPatient(patientIDToBill);
                    if (patientToBill != null) {
                        // Find or create billing record
                        Billing billing = pms.findBillingRecord(patientToBill);

                        // Allow manual input for the billing amount
                        System.out.print("Enter the billing amount for this patient: $");
                        double manualBillingAmount = scanner.nextDouble();
                        scanner.nextLine(); // Consume newline character
                        billing.setManualBillingAmount(manualBillingAmount); // Set manually entered billing amount

                        System.out.println("Bill generated successfully.");
                        System.out.println("Outstanding Balance: $" + billing.getOutstandingBalance());
                    } else {
                        System.out.println("Patient not found.");
                    }
                    break;



                case 11:
                    // Reschedule an appointment
                    System.out.print("Enter the appointment ID to reschedule: ");
                    int appointmentIDToReschedule = scanner.nextInt();
                    scanner.nextLine(); // Consume newline character

                    // Find the appointment
                    Appointment appointmentToReschedule = pms.findAppointment(appointmentIDToReschedule);
                    if (appointmentToReschedule != null) {
                        System.out.print("Enter the new appointment date (YYYY-MM-DD): ");
                        String newDate = scanner.nextLine();
                        System.out.print("Enter the new appointment time (HH:MM AM/PM): ");
                        String newTime = scanner.nextLine();

                        // Reschedule the appointment
                        appointmentToReschedule.reschedule(newDate, newTime);
                        System.out.println("Appointment rescheduled successfully.");
                    } else {
                        System.out.println("Appointment not found.");
                    }
                    break;

                case 5:
                 ///for the data baseee bounussss


                 // Update Contact Information
                    System.out.print("Enter patient ID to update contact information: ");
                    int patientIDToUpdate = scanner.nextInt();
                    scanner.nextLine(); // Consume newline character

                    System.out.print("Enter the new email address: ");
                    String newEmail = scanner.nextLine();

                    // Update the patient's email in the database
                    try (Connection connection = connectToDatabase()) {
                        String updateSQL = "UPDATE patients SET Contactinfo = ? WHERE patientID = ?";
                        try (PreparedStatement statement = connection.prepareStatement(updateSQL)) {
                            statement.setString(1, newEmail);
                            statement.setInt(2, patientIDToUpdate);

                            int rowsUpdated = statement.executeUpdate();
                            if (rowsUpdated > 0) {
                                System.out.println("Contact information updated successfully!");
                            } else {
                                System.out.println("Patient with ID " + patientIDToUpdate + " not found.");
                            }
                        }
                    } catch (SQLException e) {
                        System.out.println("Error updating contact information: " + e.getMessage());
                    }
                    break;



//                    // Update contact information
//                    System.out.print("Enter patient ID to update contact information: ");
//                    int patientIDToUpdate = scanner.nextInt();
//                    scanner.nextLine(); // Consume newline character
//
//                    Patient patientToUpdate = pms.findPatient(patientIDToUpdate);
//                    if (patientToUpdate != null) {
//                        System.out.print("Enter new contact information: ");
//                        String newContactInfo = scanner.nextLine();
//                        patientToUpdate.updateContactInfo(newContactInfo);
//                        System.out.println("Contact information updated successfully for " + patientToUpdate.getName());
//                    } else {
//                        System.out.println("Patient not found.");
//                    }
//                    break;

                case 13:
                    // Search for a patient by ID
                    System.out.print("Enter patient ID to search: ");
                    int patientIDToSearch = scanner.nextInt();
                    scanner.nextLine(); // Consume newline character

                    // Find the patient
                    Patient patientToSearch = pms.findPatient(patientIDToSearch);
                    if (patientToSearch != null) {
                        System.out.println("Patient found: " + patientToSearch);
                    } else {
                        System.out.println("Patient not found.");
                    }
                    break;

                case 6:
                    // Exit
                    System.out.println("Exiting the system...");
                    scanner.close();
                    return;






                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
