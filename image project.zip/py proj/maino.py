import datetime
import streamlit as st
import cv2
import numpy as np
from PIL import Image
import json
import os
from io import BytesIO
from datetime import datetime
from skimage.util import random_noise
from streamlit_image_comparison import image_comparison 
import matplotlib.pyplot as plt

USERS_FILE = "users.json"

# ------------------ User Handling Functions ------------------
def load_users():
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, "r") as ff:
            return json.load(ff)
    return {}

def save_users(users):
    with open(USERS_FILE, "w") as ff:
        json.dump(users, ff)

def authenticate(email, password):
    return (
        email in st.session_state.users
        and st.session_state.users[email]["password"] == password
    )

def calculate_age(dob):
    today = datetime.now()
    dob_date = datetime.strptime(dob, "%Y-%m-%d")
    age = today.year - dob_date.year - ((today.month, today.day) < (dob_date.month, dob_date.day))
    return age

def register_user(first_name, last_name, dob, email, password):
    if email in st.session_state.users:
        return False
    st.session_state.users[email] = {
        "first_name": first_name,
        "last_name": last_name,
        "dob": str(dob),
        "password": password,
        "enhancement_count": 0,
        "enhancement_types": [],
        "enhancement_history": []
    }
    save_users(st.session_state.users)
    return True

# ------------------ Enhancement Functions ------------------
def apply_histogram_equalization(image):
    if len(image.shape) == 2:
        equalized = cv2.equalizeHist(image)
        return cv2.cvtColor(equalized, cv2.COLOR_GRAY2BGR)
    else:
        img_yuv = cv2.cvtColor(image, cv2.COLOR_BGR2YUV)
        img_yuv[:,:,0] = cv2.equalizeHist(img_yuv[:,:,0])
        return cv2.cvtColor(img_yuv, cv2.COLOR_YUV2BGR)

def apply_gaussian_blur(image):
    return cv2.GaussianBlur(image, (5, 5), 0)

def apply_sharpening(image):
    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
    return cv2.filter2D(image, -1, kernel)

def apply_edge_detection(image):
    edges = cv2.Canny(image, 100, 200)
    return cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)

def apply_complement(image):
    img_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    complement = cv2.bitwise_not(img_gray)
    return cv2.cvtColor(complement, cv2.COLOR_GRAY2BGR)

def apply_salt_and_pepper(image):
    img_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    noisy = random_noise(img_gray, mode='s&p', amount=0.05)
    noisy = np.array(255 * noisy, dtype='uint8')
    return cv2.cvtColor(noisy, cv2.COLOR_GRAY2BGR)

def apply_denoise(image):
    return cv2.fastNlMeansDenoisingColored(image, None, 10, 10, 7, 21)

# ------------------ Session Init ------------------
if "users" not in st.session_state:
    st.session_state.users = load_users()
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False
if "current_user" not in st.session_state:
    st.session_state.current_user = None
if "enhanced_image" not in st.session_state:
    st.session_state.enhanced_image = None
if "original_image" not in st.session_state:
    st.session_state.original_image = None
if "tab_selection" not in st.session_state:
    st.session_state.tab_selection = "Enhancement"

# ------------------ Title ------------------
st.title("🖼️ Image Enhancement Web Application")

# ------------------ Sidebar Navigation ------------------
if not st.session_state.authenticated:
    choice = st.sidebar.selectbox("Choose an option", ["Login", "Register"])
else:
    st.session_state.tab_selection = st.sidebar.radio("📂 Navigate", ["Enhancement", "My Profile", "Charts"])

# ------------------ Registration ------------------
if not st.session_state.authenticated and choice == "Register":
    st.subheader("📝 Create a New Account")
    first_name = st.text_input("First Name")
    last_name = st.text_input("Last Name")
    dob = st.date_input("Date of Birth", max_value=datetime.now(), min_value=datetime(1925, 1, 1))
    email = st.text_input("Email")
    password = st.text_input("Password", type="password")
    confirm_password = st.text_input("Confirm Password", type="password")
    if st.button("Register"):
        if not all([first_name, last_name, email, password, confirm_password]):
            st.error("Please fill all fields.")
        elif password != confirm_password:
            st.error("Passwords do not match.")
        elif email in st.session_state.users:
            st.error("Email already registered.")
        else:
            if register_user(first_name, last_name, dob, email, password):
                st.success("Registration successful! Please log in.")
                st.balloons()    

# ------------------ Login ------------------
if not st.session_state.authenticated and choice == "Login":
    st.subheader("🔐 Login")
    email = st.text_input("Email")
    password = st.text_input("Password", type="password")
    if st.button("Login"):
        if authenticate(email, password):
            st.session_state.authenticated = True
            st.session_state.current_user = email
            st.success("Login successful!")
            st.session_state.tab_selection = "Enhancement"
        else:
            st.error("Invalid credentials.")

# ------------------ Enhancement Tab ------------------
if st.session_state.authenticated and st.session_state.tab_selection == "Enhancement":
    user = st.session_state.users[st.session_state.current_user]
    uploaded_file = st.file_uploader("📤 Upload an Image", type=["jpg", "jpeg", "png", "bmp", "tiff"])

    if uploaded_file is not None:
        image = Image.open(uploaded_file)
        image_np = np.array(image.convert("RGB"))
        image_bgr = cv2.cvtColor(image_np, cv2.COLOR_RGB2BGR)
        st.session_state.original_image = image_bgr
        st.image(image, caption="Original Image", use_column_width=True)

    if st.session_state.original_image is not None:
        enhancement_option = st.selectbox("✨ Select Enhancement", [
            "1-Histogram Equalization", "2-Gaussian Blur", "3-Sharpening",
            "4-Edge Detection", "5-Complement Enhancement",
            "6-Salt and Pepper Noise", "7-Denoise"
        ])

        if st.button("Apply Enhancement"):
            img = st.session_state.original_image
            if "1" in enhancement_option: result = apply_histogram_equalization(img)
            elif "2" in enhancement_option: result = apply_gaussian_blur(img)
            elif "3" in enhancement_option: result = apply_sharpening(img)
            elif "4" in enhancement_option: result = apply_edge_detection(img)
            elif "5" in enhancement_option: result = apply_complement(img)
            elif "6" in enhancement_option: result = apply_salt_and_pepper(img)
            elif "7" in enhancement_option: result = apply_denoise(img)

            st.session_state.enhanced_image = result
            st.session_state.users[st.session_state.current_user]["enhancement_count"] += 1
            if enhancement_option not in user["enhancement_types"]:
                user["enhancement_types"].append(enhancement_option)
            user["enhancement_history"].append({
                "technique": enhancement_option,
                "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
            save_users(st.session_state.users)

    if st.session_state.enhanced_image is not None:
        original_rgb = cv2.cvtColor(st.session_state.original_image, cv2.COLOR_BGR2RGB)
        enhanced_rgb = cv2.cvtColor(st.session_state.enhanced_image, cv2.COLOR_BGR2RGB)
        image_comparison(img1=original_rgb, img2=enhanced_rgb, label1="Original", label2="Enhanced", width=700)
        st.image(enhanced_rgb, caption="Enhanced Image", use_column_width=True)

        # Dropdown to select format
        download_format = st.selectbox("Select Download Format", ["PNG", "JPG", "WebP"])

        # Function to convert image to bytes for download in different formats
        def image_to_bytes(image, format):
            buf = BytesIO()
            image.save(buf, format=format)
            return buf.getvalue()

        if download_format == "PNG":
            st.download_button(
                label="Download Enhanced Image as PNG",
                data=image_to_bytes(Image.fromarray(enhanced_rgb), 'PNG'),
                file_name="enhanced_image.png",
                mime="image/png"
            )
        elif download_format == "JPG":
            st.download_button(
                label="Download Enhanced Image as JPG",
                data=image_to_bytes(Image.fromarray(enhanced_rgb), 'JPEG'),
                file_name="enhanced_image.jpg",
                mime="image/jpeg"
            )
        elif download_format == "WebP":
            st.download_button(
                label="Download Enhanced Image as WebP",
                data=image_to_bytes(Image.fromarray(enhanced_rgb), 'WebP'),
                file_name="enhanced_image.webp",
                mime="image/webp"
            )

# ------------------ Profile Tab ------------------
if st.session_state.authenticated and st.session_state.tab_selection == "My Profile":
    user = st.session_state.users[st.session_state.current_user]
    st.subheader("👤 My Profile")
    st.markdown(f"""
    **Name:** {user['first_name']} {user['last_name']}  
    **Email:** {st.session_state.current_user}  
    **Date of Birth:** {user['dob']}  
    **Age:** {calculate_age(user['dob'])}  
    **Enhancement Count:** {user['enhancement_count']}  
    **Techniques Used:** {', '.join(user['enhancement_types']) if user['enhancement_types'] else 'None'}
    """)

    st.markdown("### Enhancement History")
    for record in user.get("enhancement_history", []):
        st.markdown(f"- {record['date']} : {record['technique']}")

# ------------------ Charts Tab ------------------
if st.session_state.authenticated and st.session_state.tab_selection == "Charts":
    user = st.session_state.users[st.session_state.current_user]
    st.subheader("📊 Enhancement Charts")

    history = user.get("enhancement_history", [])
    if history:
        techniques = [entry["technique"] for entry in history]
        counts = {tech: techniques.count(tech) for tech in set(techniques)}

        # Pie chart
        fig1, ax1 = plt.subplots()
        ax1.pie(counts.values(), labels=counts.keys(), autopct='%1.1f%%', startangle=90)
        ax1.axis('equal')
        st.pyplot(fig1)

        # Bar chart
        fig2, ax2 = plt.subplots()
        ax2.bar(counts.keys(), counts.values(), color='green')
        ax2.set_ylabel('Frequency')
        ax2.set_title('Enhancement Usage Frequency')
        st.pyplot(fig2)
    else:
        st.info("No enhancement history yet to show charts.")

# ------------------ Logout ------------------
if st.session_state.authenticated:
    if st.button("🚪 Logout"):
        st.session_state.authenticated = False
        st.session_state.current_user = None
        st.session_state.original_image = None
        st.session_state.enhanced_image = None
        st.session_state.tab_selection = "Enhancement"
        st.success("Logged out successfully.")
        st.snow()
