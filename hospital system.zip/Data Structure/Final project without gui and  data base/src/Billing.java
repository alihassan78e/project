import java.util.*;

public class Billing {
    private Patient patient;
    private double billingAmount;
    private List<Double> paymentHistory;

    // Constructor
    public Billing(Patient patient) {

        this.patient = patient;
        this.billingAmount = 0.0;
        this.paymentHistory = new ArrayList<>();
    }

    // Getter for patient
    public Patient getPatient() {

        return patient;
    }
    public void setManualBillingAmount(double amount) {
        if (amount < 0) {
            System.out.println("Invalid billing amount. Must be non-negative.");
            return;
        }
        this.billingAmount = amount;
        System.out.println("Billing amount for " + patient.getName() + " set to $" + amount);
    }
    public double getTotalPayments() {
        double totalPayments = 0.0;
        for (double payment : paymentHistory) {
            totalPayments += payment;
        }
        return totalPayments;
    }
    public double getOutstandingBalance() {
        return billingAmount; // The billing amount decreases as payments are made.
    }


    // Generate bill by calculating total based on appointments (assuming a fixed charge for simplicity)
    public void generateBill(List<Appointment> appointments) {
        double totalAmount = 0.0;

        // Iterate through the appointments and calculate the total amount
        for (Appointment appointment : appointments) {
            if (appointment.getPatient().getPatientID() == patient.getPatientID()) {
                // Assume each appointment has a fixed cost of $100 per visit
                totalAmount += 100;  // Change this logic to whatever you need for pricing
            }
        }

        // Update the billingAmount field to the calculated total amount
        this.billingAmount = totalAmount;
        System.out.println("Generated a bill for patient: " + patient.getName() + " with total amount: $" + billingAmount);
    }


    // Add payment and update the balance
    public void addPayment(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid payment amount. Must be greater than zero.");
            return;
        }
        if (amount > billingAmount) {
            System.out.println("Payment exceeds the current billing amount. Payment not processed.");
            return;
        }
        paymentHistory.add(amount);
        billingAmount -= amount;
        System.out.println("Payment of $" + amount + " added for patient: " + patient.getName());
    }

    // Get the payment status (outstanding balance)
    public String getPaymentStatus() {
        return "Outstanding Balance for " + patient.getName() + " (ID: " + patient.getPatientID() + "): $" + billingAmount;
    }

    // Display the payment history
    public void displayPaymentHistory() {
        System.out.println("Payment History for " + patient.getName() + ": " + paymentHistory);
    }

    // Display the current balance
    public void displayBalance() {
        System.out.println("Current balance for patient " + patient.getName() + ": $" + billingAmount);
    }
}
