public class Appointment {
    private int appointmentID;
    private Patient patient; // Association with Patient class
    private String date;
    private String time;
    private String status;

    public Appointment(int appointmentID, Patient patient, String date, String time) {
        this.appointmentID = appointmentID;
        this.patient = patient;
        this.date = date;
        this.time = time;
        this.status = "Scheduled"; // Default status
    }

    public int getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Methods
    public void schedule(String newDate, String newTime) {
        this.date = newDate;
        this.time = newTime;
        this.status = "Scheduled";
        System.out.println("Appointment scheduled on " + patient.getName()+ newDate + " at " + newTime);
    }

    public void cancel() {
        this.status = "Cancelled";
        System.out.println("Appointment with ID " + appointmentID + " has been cancelled.");
    }

    public void reschedule(String newDate, String newTime) {
        this.date = newDate;
        this.time = newTime;
        this.status = "Rescheduled";
        System.out.println("Appointment rescheduled to " + newDate + " at " + newTime);
    }

    @Override
    public String toString() {
        return "Appointment{" +
                "appointmentID=" + appointmentID +
                ", patient=" + patient.getName() +
                ", date='" + date + '\'' +
                ", time='" + time + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
